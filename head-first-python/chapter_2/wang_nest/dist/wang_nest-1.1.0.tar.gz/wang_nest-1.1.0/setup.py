from distutils.core import setup

setup(
    name = 'wang_nest',
    version = '1.1.0',
    py_modules = ['wang_nest'],
    author = 'wangyuan',
    author_email = 'wangyuanfu315@gmail.com',
    url = 'http://headfirstlabs.com',
    description = 'A simple printer of nested lists',

)
