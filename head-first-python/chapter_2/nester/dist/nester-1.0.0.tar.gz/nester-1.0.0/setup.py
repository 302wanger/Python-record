from distutils.core import setup

setup(
    name = 'nester',
    version = '1.0.0',
    py_modules = ['nester'],
    author = 'wangyuan',
    author_email = 'wangyuanfu315@gmail.com',
    url = 'http://headfirstlabs.com',
    description = 'A simple printer of nested lists.',

)
